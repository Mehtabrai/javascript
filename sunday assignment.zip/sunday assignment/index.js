
// var RandomNum= Math.random(10)

// console.log(RandomNum)

var RandomNum = Math.floor(6);

var propmt=Number(prompt(" Enter number from 1-10 (neglect any number if <1 or >10 )"));

if( propmt === RandomNum ){
    alert("Your number is in the lucky draw");
    console.log("<<<---- Your number is in the lucky draw----->>>", propmt)
}

else{
    alert("Sorry you're not selected");
console.log("<<<----  Sorry you're not selected ----->>>", propmt)
}
    


